<html>
<head>
  <script type="text/javascript">
  function loadNewDoc(){
      window.location="http://localhost/project/requestsuccess.html";
  }
  </script>
</head>
<body onLoad="setTimeout('loadNewDoc()', 5000)">
  <h1>Redirecting.......</h1>
</body>
</html>
